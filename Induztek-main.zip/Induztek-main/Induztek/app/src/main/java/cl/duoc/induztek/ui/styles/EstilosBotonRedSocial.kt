package cl.duoc.induztek.ui.styles

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.graphics.Shape
import cl.duoc.induztek.ui.theme.Dimens

object EstilosBotonRedSocial {
    val forma: Shape = RoundedCornerShape(Dimens.radioBotonRedsocial)

    const val anchoRelativoDelGrupo = 0.85f
}
