package cl.duoc.induztek.ui.theme

import androidx.compose.ui.unit.dp

object Dimens{
    val espacioMini = 4.dp
    val espacioChico = 8.dp
    val espacioMedio = 16.dp
    val espacioGrande = 24.dp

    val margenHorizontalPantalla = 30.dp




    val espacioSuperiorencabezado = 90.dp

    //entre el encabezado y el formulario.
    val espacioEncabezadoACuerpo = 70.dp

    val alturaEntrarcomo = 100.dp

    val alturaCampo = 34.dp
    val alturaCampoTextoLargo = 84.dp
    val radioCampo = 12.dp
    val bordeCampo = 1.dp
    val espacioCampoHorizontal = 12.dp
    val espacioEtiquetaACampo = 6.dp
    val espacioEntreCampos = 10.dp
    val espacioNombreApellido = 12.dp
    val tamanoIconoCampo = 18.dp


    val alturaBoton = 34.dp
    val radioBoton = 12.dp
    val elevacionBoton = 0.dp


    val alturaBotonRedsocial = 34.dp
    val radioBotonRedsocial = 10.dp
    val elevacionBotonRedsocial = 4.dp
    val tamanoIconoRedSocial = 18.dp
    val espacioRedes = 12.dp

    val espacioAntescorreo = 24.dp
    val espacioDespuesTextoCorreo = 12.dp
    val espacioAntesBoton = 16.dp
    val espacioAntesRedes = 10.dp
    val espacioTextoRedes = 12.dp
    val espacioAntesSinCuenta = 22.dp





    val proporcionAlturaBanner = 0.33f
    val opacidadVelo = 0.35f
    val inicioDifuminado = 0.5f



    val paradaDifuminado = 0.5f





    val salto1 = 4.dp
    val salto2 = 6.dp
    val salto3 = 8.dp
    val salto4 = 10.dp
    val salto5 = 12.dp
    val salto6 = 14.dp
    val salto7 = 16.dp
    val salto8 = 20.dp
    val salto9 = 24.dp




    val radioTarjeta = 14.dp
    val bordeTarjeta = 1.dp
    val rellenoTarjeta = 14.dp
    val alturaBotonGrande = 52.dp
    val radioChip = 20.dp
    val radioAviso = 10.dp
    val rellenoAviso = 10.dp
    val chipAlpha = 0.12f
    val iconoAlpha = 0.15f
    val avisoAlpha = 0.08f
    val alfaCajaBlanca = 0.6f



    val tamanoIconoResultado = 26.dp
    val anchoBarraAcento = 3.dp
    val altoBarraAcento = 18.dp



    val tamanoBotonAtras = 32.dp
    val espacioTituloAtras = 6.dp
    val espacioEncabezadoCuerpo = 8.dp



    val alturaPestana = 40.dp
    val grosorPestana = 2.dp
    val espacioPestanaAContent = 12.dp



    val radioCaja = 12.dp
    val rellenoCaja = 12.dp
    val anchoCajaFlecha = 44.dp


    val alturaSegmento = 34.dp
    val radioSegmento = 10.dp


    val alturaActaCabecera = 44.dp
    val radioActa = 12.dp
    val alturaFilaPrueba = 44.dp
    val radioBotonChico = 10.dp
    val rellenoBotonChicoH = 12.dp
    val rellenoBotonChicoV = 6.dp



    val tamanoAvatar = 46.dp
    val rellenoChipVertical = 3.dp
    val altoGrafico = 160.dp

    val altoCabeceraCliente = 96.dp
    val desplomeCabeceraCliente = 10.dp
    val grosorBordeAvatar = 3.dp
    val altoBarraNavegacion = 68.dp
    val tamanoIconoNav = 22.dp
    val alturaBuscador = 56.dp
    val anchoCajaActa = 104.dp
    val altoCajaActa = 62.dp
    val anchoEstadoHistorial = 92.dp
    val altoDivisorFila = 32.dp
    val grosorDivisor = 1.dp
    val altoDivisorColumna = 44.dp
    val margenPantalla = 20.dp
    val tamanoCirculoFlecha = 30.dp



    val anchoRelativoBarra = 0.62f
    val factorAltoBarras = 0.74f
    val radioBarras = 10f
    val grosorTrazoHatch = 2.5f
    val espacioTrazoHatch = 9f
    val alfaBarraSolida = 0.5f
    val alfaBarraFondo = 0.08f
    val alfaTrazoHatch = 0.35f
}



