package cl.duoc.induztek.ui.theme

import androidx.compose.ui.graphics.Color


val TextoGris = Color(0xFF474A60) //titulos, eslogan, etiquetas y enlaces.
val TextoPlaceholder = Color(0xFFD9DAE6)
val TextoOlvido = Color(0xFFB1B2C1)
val BordeCampo = Color(0xFFDDDEE9) //sin selecionar
val FondoCampo = Color(0xFFFFFFFF)
val IconoCampo = Color(0xFFD3D4DB) //ojo de contraseñas y flecha de listas
val BotonDeshabilitado = Color(0xFFC9CBDC) //campos vacios.
val FondoRedSocial = Color(0xFFFFFFFF) //cuadritos para google, linkedin y fabebook.
val FondoPantalla = Color(0xFFFFFFFF)




val TextoGrisClaro = Color(0xFF474A60) //titulos, eslogan, etiquetas y enlaces.
val TextoGrisOscuro = Color(0xFFC3C6D9)
val TextoPlaceholderClaro = Color(0xFFD9DAE6)
val TextoPlaceholderOscuro = Color(0xFF5A5A6E)
val TextoOlvidoClaro = Color(0xFFB1B2C1)
val TextoOlvidoOscuro = Color(0xFF8E8FA3)
val BordeCampoClaro = Color(0xFFDDDEE9) //sin selecionar
val BordeCampoOscuro = Color(0xFF3A3850)
val FondoCampoClaro = Color(0xFFFFFFFF)
val FondoCampoOscuro = Color(0xFF1E1C28)
val IconoCampoClaro = Color(0xFFD3D4DB) //ojo de contraseñas y flecha de listas
val IconoCampoOscuro = Color(0xFF6F6D85)
val BotonDeshabilitadoClaro = Color(0xFFC9CBDC) //campos vacios.
val BotonDeshabilitadoOscuro = Color(0xFF3C3A52)
val FondoRedSocialClaro = Color(0xFFFFFFFF) //cuadritos para google, linkedin y fabebook.
val FondoRedSocialOscuro = Color(0xFF232132)
val FondoPantallaClaro = Color(0xFFFFFFFF)
val FondoPantallaOscuro = Color(0xFF121018)




val Primario = Color(0xFF5B3FD9)
val TextoOscuro = Color(0xFF1C1B22)



val PrimarioClaro = Color(0xFF5B3FD9)
val PrimarioOscuro = Color(0xFF8E76EC)
val Blanco = Color(0xFFFFFFFF)
val Negro = Color(0xFF121018)
val TextoOscuroClaro = Color(0xFF1C1B22)
val TextoOscuroOscuro = Color(0xFFEDEBFF)



val MoraditoClaro = Color(0xFFE3DEFF)
val fonditoMorado = Color(0xFFF5F1FF)



val MoraditoFinClaro = Color(0xFFE3DEFF) //ultima parada del degradado de las pantallas
val MoraditoFinOscuro = Color(0xFF241E3E)







val Purple80 = Color(0xFFD0BCFF)
val PurpleGrey80 = Color(0xFFCCC2DC)
val Pink80 = Color(0xFFEFB8C8)
val Purple40 = Color(0xFF6650a4)
val PurpleGrey40 = Color(0xFF625b71)
val Pink40 = Color(0xFF7D5260)



val fonditoMoradoClaro = Color(0xFFF5F1FF)
val fonditoMoradoOscuro = Color(0xFF171426)


val LavandaPrimario = Color(0xFF6C63A6)
val LavandaSuave = Color(0xFFE4E1F5)
val LavandaFondo = Color(0xFFF7F6FC)
val LavandaBorde = Color(0xFFD6D2EC)
val VerdeAprobado = Color(0xFF3E8E5A)
val NaranjaObservado = Color(0xFFB8860B)
val RojoRechazado = Color(0xFFC0392B)
val GrisTexto = Color(0xFF6B6B78)
val FondoFilaTabla = Color(0xFFF2F1F8)
val LavandaActa = Color(0xFFB6AFDD)
val MoradoFondo = Color(0xFFD9D3EF)




val LavandaPrimarioClaro = Color(0xFF6C63A6)
val LavandaPrimarioOscuro = Color(0xFF9B93D6)
val LavandaSuaveClaro = Color(0xFFE4E1F5)
val LavandaSuaveOscuro = Color(0xFF2A2740)
val LavandaFondoClaro = Color(0xFFF7F6FC)
val LavandaFondoOscuro = Color(0xFF14121D)
val LavandaBordeClaro = Color(0xFFD6D2EC)
val LavandaBordeOscuro = Color(0xFF3E3A5F)
val VerdeAprobadoClaro = Color(0xFF3E8E5A)
val VerdeAprobadoOscuro = Color(0xFF6FD39B)
val NaranjaObservadoClaro = Color(0xFFB8860B)
val NaranjaObservadoOscuro = Color(0xFFE3B341)
val RojoRechazadoClaro = Color(0xFFC0392B)
val RojoRechazadoOscuro = Color(0xFFEF7B6C)
val GrisTextoClaro = Color(0xFF6B6B78)
val GrisTextoOscuro = Color(0xFFB4B4C2)
val FondoFilaTablaClaro = Color(0xFFF2F1F8)
val FondoFilaTablaOscuro = Color(0xFF211E31)
val LavandaActaClaro = Color(0xFFB6AFDD)
val LavandaActaOscuro = Color(0xFF4A4373)
val MoradoFondoClaro = Color(0xFFD9D3EF)
val MoradoFondoOscuro = Color(0xFF2C2745)
